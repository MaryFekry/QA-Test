describe('First Test', function(){
    it('test for register', function(){
        cy.visit('https://demo.realworld.io/#/')
        cy.get('a[href="#/register"]').contains('Sign up').click()
        cy.url().should('include','#/register')
        cy.get('input[placeholder="Username"]').type('Mery Fekry')
        cy.get('input[placeholder="Email"]').type('mary.fekry96@gmail.com')
        cy.get('input[placeholder="Password"]').type('mery12345')
        cy.get('button[type="submit"]').click()
        cy.pause()

    })
    it('test for login', function(){
        cy.get('a[href="#/login"]').first().click()
        cy.url().should('include','#/login')
        cy.get('input[placeholder="Email"]').type('mary.fekry96@gmail.com')
        cy.get('input[placeholder="Password"]').type('mery12345')
        cy.get('button[type="submit"]').contains('Sign in').click()
        cy.url().should('eq','https://demo.realworld.io/#/')
        cy.pause()
        cy.get('a[href="#/editor/"]').contains('New Article').click('top')
        cy.pause()
        // for create new article
        // cy.url().should('include','#/editor')
        // cy.get('input[placeholder="Article Title"]').type('Article for cypress test')
        // cy.get('input[placeholder="What\'s this article about?"]').type('Article for cypress test')
        // cy.get('textarea[placeholder="Write your article (in markdown)"]').type('Article for cypress test')
        // cy.get('input[placeholder="Enter tags"]').type('#test1')
        // cy.get('button[type="button"]').contains('Publish Article').click()
        // cy.url().should('include','#/article')
        // cy.pause()
        //for mark a post
        // cy.get('a[href="#/@Mery%20Fekry"]').first().click()
        // cy.url().should('include','#/@Mery%20Fekry')
        // cy.get('favorite-btn').first().click()
    })
    it('test for create new article', function(){
        cy.url().should('include','#/editor')
        cy.get('input[placeholder="Article Title"]').type('Article for cypress test')
        cy.get('input[placeholder="What\'s this article about?"]').type('Article for cypress test')
        cy.get('textarea[placeholder="Write your article (in markdown)"]').type('Article for cypress test')
        cy.get('input[placeholder="Enter tags"]').type('#test1')
        cy.get('button[type="button"]').contains('Publish Article').click()
        // cy.url().should('include','#/article')
    })

    // it('for mark a post', function(){
    //     cy.get('a[href="#/@Mery%20Fekry"]').first().click()
    //     cy.url().should('include','#/@Mery%20Fekry')
    //     cy.get('favorite-btn').first().click()
    // })
    
})

